# The Agent Company — operating context

A UK industrial business supplies components and configured equipment to business customers, combines purchased parts with warehouse stock, and coordinates engineering, assembly, dispatch and after-sales support.

## Purchase To Pay
Approved requirement → purchase order → physical receipt → invoice matching → payment preparation. Investigate differences before changing financial documents.

## Order To Cash
Customer order → stock/assembly coordination → dispatch → sales invoice → receipt allocation.

## Payroll
Approved time and leave inputs → workbook reconciliation → native payroll preparation → finance review.

## Customer Service
Read request and native order facts → investigate with responsible colleague → record accurate response and next action.

## Financial Controls
Do not treat an invoice or spreadsheet assertion as proof of goods received. Retain source references and explain discrepancies.

## Payroll
Use approved HR inputs; distinguish missing approval from an incorrect total; do not invent employee bank or tax details.

## Customer Communications
Only promise dates supported by warehouse or responsible owner evidence.

## Working Records
Keep original evidence intact and create a separate reconciled working copy. Internal evaluation evidence is never employee-facing.
